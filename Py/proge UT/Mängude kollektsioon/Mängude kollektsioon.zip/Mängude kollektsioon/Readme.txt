Mänge saab hakkata lihtsasti mängima läbi MAIN.py faili avamisega ning selle koodi käima panemisega.

Enne mängimist peab olema istallitud PyGame, EasyGui ja TKinter, neid saab installida läbi konsooli paari komandiga:
(konsooli saab avada CMD kirjutamisega windowsi otsingu ribale start menüüs)

1. PyGame:
pip install pygame

2. EasyGui:
pip install easygui

3. TKinter:
pip install tkinter

Edu mängimisel! :)